import './App.css';
import React from 'react';

import Attendees from './components/Attendees';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Attendees />
    </div>
  );
}

export default App;
